//
//  Theme.swift
//  iOSBootcampFinalProject
//
//  Created by TTN on 28/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class Theme {
    
    static var current: ThemeProtocol = LightTheme()
    
}
