//
//  HomeViewModel.swift
//  iOSBootcampFinalProject
//
//  Created by TTN on 30/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import Foundation

class HomeViewModel {
    
    var homeApiData: [HomeData] = []
    
    func fetchHomeApiData(completion: @escaping (Bool,String) -> Void){
        
        homeApiData.removeAll()
        for (index,genre) in ApiConstants.genre.allCases.enumerated(){
            NetworkManager().fetchApiData(urlType: .home(genre)) { (result) in
                print(genre.rawValue)
                switch result{
                case .success(let data):
                    self.homeApiData.append(HomeData(sectionTitle: genre.rawValue, movieData: data.results))
                    if index == ApiConstants.genre.allCases.count - 1{
                    completion(true, "")
                    }
                case .failure(let error):
                    completion(false, error.localizedDescription)
                }
            }
        }
    }
    
}
